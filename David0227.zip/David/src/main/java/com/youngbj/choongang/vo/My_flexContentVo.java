package com.youngbj.choongang.vo;

public class My_flexContentVo {

	private String mbr_idx;
	private String flx_idx;
	private String flx_ttl;
	private String flx_con;
	private String flx_fdat;
	private String flx_iurl;
	private String flx_vurl;
	private String flx_lcnt;
	private String flx_rcnt;
	
	public My_flexContentVo() {
		super();
	}

	public My_flexContentVo(String mbr_idx, String flx_idx, String flx_ttl, String flx_con, String flx_fdat,
			String flx_iurl, String flx_vurl, String flx_lcnt, String flx_rcnt) {
		super();
		this.mbr_idx = mbr_idx;
		this.flx_idx = flx_idx;
		this.flx_ttl = flx_ttl;
		this.flx_con = flx_con;
		this.flx_fdat = flx_fdat;
		this.flx_iurl = flx_iurl;
		this.flx_vurl = flx_vurl;
		this.flx_lcnt = flx_lcnt;
		this.flx_rcnt = flx_rcnt;
	}

	public String getMbr_idx() {
		return mbr_idx;
	}

	public void setMbr_idx(String mbr_idx) {
		this.mbr_idx = mbr_idx;
	}

	public String getFlx_idx() {
		return flx_idx;
	}

	public void setFlx_idx(String flx_idx) {
		this.flx_idx = flx_idx;
	}

	public String getFlx_ttl() {
		return flx_ttl;
	}

	public void setFlx_ttl(String flx_ttl) {
		this.flx_ttl = flx_ttl;
	}

	public String getFlx_con() {
		return flx_con;
	}

	public void setFlx_con(String flx_con) {
		this.flx_con = flx_con;
	}

	public String getFlx_fdat() {
		return flx_fdat;
	}

	public void setFlx_fdat(String flx_fdat) {
		this.flx_fdat = flx_fdat;
	}

	public String getFlx_iurl() {
		return flx_iurl;
	}

	public void setFlx_iurl(String flx_iurl) {
		this.flx_iurl = flx_iurl;
	}

	public String getFlx_vurl() {
		return flx_vurl;
	}

	public void setFlx_vurl(String flx_vurl) {
		this.flx_vurl = flx_vurl;
	}

	public String getFlx_lcnt() {
		return flx_lcnt;
	}

	public void setFlx_lcnt(String flx_lcnt) {
		this.flx_lcnt = flx_lcnt;
	}

	public String getFlx_rcnt() {
		return flx_rcnt;
	}

	public void setFlx_rcnt(String flx_rcnt) {
		this.flx_rcnt = flx_rcnt;
	}
	
	
	
}
