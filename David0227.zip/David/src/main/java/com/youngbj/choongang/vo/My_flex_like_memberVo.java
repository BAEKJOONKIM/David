package com.youngbj.choongang.vo;

public class My_flex_like_memberVo {
	
	private String flx_idx;
	private String mbr_idx;
	
	public My_flex_like_memberVo() {
		super();
	}

	public My_flex_like_memberVo(String flx_idx, String mbr_idx) {
		super();
		this.flx_idx = flx_idx;
		this.mbr_idx = mbr_idx;
	}

	public String getFlx_idx() {
		return flx_idx;
	}

	public void setFlx_idx(String flx_idx) {
		this.flx_idx = flx_idx;
	}

	public String getMbr_idx() {
		return mbr_idx;
	}

	public void setMbr_idx(String mbr_idx) {
		this.mbr_idx = mbr_idx;
	}
	
	

}
