package com.youngbj.choongang.vo;

public class WorkOutCategoryVo {

	private String wrk_cat;
	private String wrk_catn;
	
	public WorkOutCategoryVo() {
		super();
	}

	public WorkOutCategoryVo(String wrk_cat, String wrk_catn) {
		super();
		this.wrk_cat = wrk_cat;
		this.wrk_catn = wrk_catn;
	}

	public String getWrk_cat() {
		return wrk_cat;
	}

	public void setWrk_cat(String wrk_cat) {
		this.wrk_cat = wrk_cat;
	}

	public String getWrk_catn() {
		return wrk_catn;
	}

	public void setWrk_catn(String wrk_catn) {
		this.wrk_catn = wrk_catn;
	}
	
	
}
